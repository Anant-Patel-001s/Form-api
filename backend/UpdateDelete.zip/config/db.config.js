module.exports = {
  url: "mongodb+srv://uditsinh:5I32PwdYsILnbHFv@cluster0.1cwkrbv.mongodb.net/test",
};
